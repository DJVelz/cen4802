import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestBookReview {
    @Test
    public void testExample() {
        assertEquals(2, 1 + 1);
    }
}
